class Article
  attr_accessor :id, :title, :body
  def initialize
    @id, @title, @body = 1, 'Hello', 'World'
  end
end